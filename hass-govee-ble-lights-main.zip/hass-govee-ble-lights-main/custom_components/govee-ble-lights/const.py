DOMAIN = "govee-ble-lights"
